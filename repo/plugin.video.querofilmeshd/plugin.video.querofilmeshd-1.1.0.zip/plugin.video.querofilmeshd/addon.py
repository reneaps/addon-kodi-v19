#####################################################################
# -*- coding: utf-8 -*-
#####################################################################
# Addon : QueroFilmesHD
# By AddonBrasil - 08/08/2020
# Atualizado (1.0.0) - 08/08/2020
# Atualizado (1.0.2) - 11/11/2020
# Atualizado (1.0.3) - 06/02/2021
# Atualizado (1.0.4) - 21/06/2021
# Atualizado (1.0.5) - 23/06/2021
# Atualizado (1.0.6) - 25/06/2021
# Atualizado (1.1.0) - 03/07/2021
#####################################################################

import urllib, re, xbmcplugin, xbmcgui, xbmc, xbmcaddon, os, time, base64
import json
import urlresolver
import requests
import resources.lib.moonwalk as moonwalk

from bs4                import BeautifulSoup
from resources.lib      import jsunpack

version   = '1.1.0'
addon_id  = 'plugin.video.querofilmeshd'
selfAddon = xbmcaddon.Addon(id=addon_id)

addonfolder = selfAddon.getAddonInfo('path')
artfolder   = addonfolder + '/resources/media/'
fanart      = addonfolder + '/fanart.png'
base        = 'https://querofilmeshd.co/'
#base64.b64decode('aHR0cHM6Ly9xdWVyb2ZpbG1lc2hkLm9ubGluZS8=')

############################################################################################################

def menuPrincipal():
        addDir('Categorias'                 , base + ''                     ,   10, artfolder + 'categorias.png')
        addDir('Lançamentos'                , base + 'filme/'               ,   20, artfolder + 'lancamentos.png')
        addDir('Seriados'                   , base + 'genero/series/'       ,   25, artfolder + 'legendados.png')
        addDir('Pesquisa Series'            , '--'                          ,   30, artfolder + 'pesquisa.png')
        addDir('Pesquisa Filmes'            , '--'                          ,   35, artfolder + 'pesquisa.png')
        addDir('Configurações'              , base                          ,  999, artfolder + 'config.png', 1, False)
        addDir('Configurações ExtendedInfo' , base                          , 1000, artfolder + 'config.png', 1, False)

        setViewMenu()

def getCategorias(url):
        link = openURL(url)
        link = unicode(link, 'utf-8', 'ignore')
        soup = BeautifulSoup(link, 'html.parser')
        conteudo   = soup("ul",{"class":"sub-menu"})
        categorias = conteudo[0]("li")

        totC = len(categorias)

        for categoria in categorias:
                titC = categoria.a.text.encode('utf-8','')
                urlC = categoria.a["href"]
                urlC = 'http:%s' % urlC if urlC.startswith("//") else urlC
                urlC = base + urlC if urlC.startswith("categoria") else urlC
                imgC = artfolder + limpa(titC) + '.png'
                addDir(titC,urlC,20,imgC)

        setViewMenu()

def getFilmes(url):
        xbmc.log('[plugin.video.querofilmeshd] L66 - ' + str(url), xbmc.LOGNOTICE)
        link = openURL(url)
        #link = unicode(link, 'utf-8', 'ignore')
        soup = BeautifulSoup(link, "html.parser")
        try:
            conteudo = soup('div',{'class':'items normal'})
            filmes=conteudo[0]('article',{'class':'item movies'})
        except:
            pass
        try:
            conteudo = soup('div',{'class':'animation-2 items normal'})
            filmes=conteudo[0]('article',{'class':'item movies'})
        except:
            pass
        totF = len(filmes)

        for filme in filmes:
                a = filme('a')
                urlF = a[0]['href'].encode('utf-8')
                titF = a[1].text.encode("utf-8")
                imgF = filme.img['data-src'].encode('utf-8')
                if 'url=' in imgF : imgF = imgF.split('=')[3]
                imgF = 'https:%s' % imgF if imgF.startswith("//") else imgF
                pltF = titF
                addDirF(titF, urlF, 100, imgF, False, totF, pltF)

        try :
                proxima = re.findall('<link rel="next" href="(.+?)" />', link)[0]
                addDir('Próxima Página >>', proxima, 20, artfolder + 'proxima.png')
        except :
                pass

        setViewFilmes()

def getSeries(url):
        xbmc.log('[plugin.video.querofilmeshd] L101- ' + str(url), xbmc.LOGNOTICE)
        link = openURL(url)
        #link = unicode(link, 'utf-8', 'ignore')
        soup = BeautifulSoup(link, "html.parser")
        try:
            conteudo = soup('div',{'class':'items normal'})
            filmes=conteudo[0]('article',{'class':'item tvshows'})
        except:
            pass
        try:
            conteudo = soup('div',{'class':'animation-2 items normal'})
            filmes=conteudo[0]('article',{'class':'item tvshows'})
        except:
            pass

        totF = len(filmes)

        for filme in filmes:
                a = filme('a')
                urlF = a[0]['href'].encode('utf-8')
                titF = a[1].text.encode("utf-8")
                imgF = filme.img['data-src'].encode('utf-8')
                if 'url=' in imgF : imgF = imgF.split('=')[3]
                imgF = 'https:%s' % imgF if imgF.startswith("//") else imgF
                pltF = titF
                addDirF(titF, urlF, 26, imgF, True, totF, pltF)

        try :
                proxima = re.findall('<link rel="next" href="(.+?)" />', link)[0]
                addDir('Próxima Página >>', proxima, 25, artfolder + 'proxima.png')
        except :
                pass

        #xbmcplugin.setContent(handle=int(sys.argv[1]), content='tvshows')
        setViewFilmes()

def getTemporadas(name,url,iconimage):
        xbmc.log('[plugin.video.querofilmeshd] L138 - ' + str(url), xbmc.LOGNOTICE)
        html = openURL(url)
        soup = BeautifulSoup(html, 'html.parser')
        conteudo = soup('div', {'id':'seasons'})
        seasons = conteudo[0]('div', {'class': 'se-c'})
        totF = len(seasons)
        imgF = ''
        urlF = url
        i = 1
        while i <= totF:
                titF = str(i) + "ª Temporada"
                try:
                    addDirF(titF, urlF, 27, iconimage, True, totF)
                except:
                    pass
                i = i + 1

        xbmcplugin.setContent(handle=int(sys.argv[1]), content='seasons')

def getEpisodios(name, url):
        xbmc.log('[plugin.video.querofilmeshd] L158 - ' + str(url), xbmc.LOGNOTICE)
        n = name.replace('ª Temporada', '')
        n = int(n)
        n = (n-1)
        temp = []
        episodios = []

        link = openURL(url)
        link = unicode(link, 'utf-8', 'ignore')
        soup = BeautifulSoup(link, 'html.parser')
        conteudo = soup('div', {'class':'se-c'})
        episodes = conteudo[n]('ul', {'class':'episodios'})
        itens = episodes[0]('li')

        totF = len(itens)

        for i in itens:
            urlF = i.a['href']
            #if not url in urlF : urlF = base + urlF
            imgF = i.img['src']
            if 'url=' in imgF : imgF = imgF.split('=')[3]
            imgF = imgF.replace('w154', 'w300')
            imgF = 'http:%s' % imgF if imgF.startswith("//") else imgF
            imgF = base + imgF if imgF.startswith("/wp-content") else imgF
            xbmc.log('[plugin.video.querofilmeshd] L182 - ' + str(imgF), xbmc.LOGNOTICE)
            titA = i(class_='numerando')[0].text.encode('utf-8').replace('-','x')
            titB = i(class_='episodiotitle')[0].a.text.encode('utf-8')
            titF = titA + ' - ' + titB
            addDirF(titF, urlF, 110, imgF, False, totF)

        xbmcplugin.setContent(handle=int(sys.argv[1]), content='episodes')

def pesquisa():
        keyb = xbmc.Keyboard('', 'Pesquisar Filmes')
        keyb.doModal()

        if (keyb.isConfirmed()):
                texto    = keyb.getText()
                pesquisa = urllib.parse.quote(texto)
                base     = 'https://querofilmehd.org/'
                url      = base + '?s=%s' % str(pesquisa)

                xbmc.log('[plugin.video.querofilmeshd] L200 - ' + str(url), xbmc.LOGNOTICE)
                hosts = []
                link = openURL(url)
                link = unicode(link, 'utf-8', 'ignore')
                soup = BeautifulSoup(link, 'html.parser')
                filmes = soup.findAll('div', {'class':'image'})
                totF = len(filmes)
                for filme in filmes:
                        titF = filme.img["alt"].encode('utf-8')
                        urlF = filme.a["href"]
                        urlF = base + urlF if urlF.startswith("/filmes") else urlF
                        urlF = base + urlF if urlF.startswith("filmes") else urlF
                        urlF = base + urlF if urlF.startswith("/series") else urlF
                        urlF = base + urlF if urlF.startswith("series") else urlF
                        urlF = base + "filmes/" + urlF if urlF.startswith("assistir") else urlF
                        imgF = filme.img["src"]
                        if 'url=' in imgF : imgF = imgF.split('=')[3]
                        imgF = imgF.replace('w92', 'w400')
                        imgF = 'http:%s' % imgF if imgF.startswith("//") else imgF
                        imgF = base + imgF if imgF.startswith("/wp-content") else imgF
                        imgF = base + imgF if imgF.startswith("wp-content") else imgF
                        temp = [urlF, titF, imgF]
                        xbmc.log('[plugin.video.querofilmeshd] L222 - ' + str(temp), xbmc.LOGNOTICE)
                        hosts.append(temp)

                a = []
                for url, titulo, img in hosts:
                    temp = [url, titulo, img]
                    a.append(temp);

                return a

def doPesquisaSeries():
        a = pesquisa()
        total = len(a)
        for url2, titulo, img in a:
            addDir(titulo, url2, 26, img, False, total)

        xbmcplugin.setContent(handle=int(sys.argv[1]), content='seasons')

def doPesquisaFilmes():
        a = pesquisa()
        total = len(a)
        for url2, titulo, img in a:
            addDir(titulo, url2, 100, img, False, total)
        setViewFilmes()

def player(name,url,iconimage):
        xbmc.log('[plugin.video.querofilmeshd] L248 - ' + str(url), xbmc.LOGNOTICE)
        OK = True
        mensagemprogresso = xbmcgui.DialogProgress()
        mensagemprogresso.create('QueroFilmesHD', 'Obtendo Fontes para ' + name, 'Por favor aguarde...')
        mensagemprogresso.update(0)

        titsT = []
        idsT = []
        sub = None

        link = openURL(url)
        dooplay = re.findall(r'<li id=[\'"]player-option-1[\'"] class=[\'"]dooplay_player_option[\'"] data-type=[\'"](.+?)[\'"] data-post=[\'"](.+?)[\'"] data-nume=[\'"](.+?)[\'"]>', link)

        for dtype, dpost, dnume in dooplay:
                print dtype, dpost, dnume
        try:
            p = soup('p', limit=5)[0]
            plot = p.text.replace('kk-star-ratings','')
        except:
            plot = 'Sem Sinopse'
            pass
        try:
                '''
                headers = {'Referer': url,
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                        'origin': base,
                        'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0'
                }
                urlF = base + 'wp-admin/admin-ajax.php'
                xbmc.log('[plugin.video.querofilmeshd] L277 - ' + str(dooplay), xbmc.LOGNOTICE)
                data = urllib.urlencode({'action': 'doo_player_ajax', 'post': dpost, 'nume': dnume, 'type': dtype})
                r = requests.post(url=urlF, data=data, headers=headers)
                html = r.content
                xbmc.log('[plugin.video.querofilmeshd] L281 - ' + str(html), xbmc.LOGNOTICE)
                try:
                    soup = BeautifulSoup(html, "html.parser")
                    urlF = soup.iframe['src']
                    urlVideo = urlF[0]
                except:
                    pass
                try:
                    b = json.loads(html)
                    urlF = str(b['embed_url'])
                    urlVideo = urlF
                except:
                    pass
                '''
                xbmc.log('[plugin.video.querofilmeshd] L295 - ' + str(url), xbmc.LOGNOTICE)
                html = requests.get(url).text
                urlF = re.findall(r"<iframe class='metaframe rptss' src='(.*?)' frameborder='0' scrolling='no' allow='autoplay; encrypted-media' allowfullscreen></iframe>", html)[0]
                html = requests.get(urlF).text
                xbmc.log('[plugin.video.querofilmeshd] L299 - ' + str(urlF), xbmc.LOGNOTICE)
                idS = re.findall(r'idS:\s*"(.*?)"', html)[0]
                headers = {'Referer': urlF,
                           'Accept': '*/*',
                           'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                           'Connection': 'keep-alive',
                           'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0'
                }
                if 'querofilmeshd' in urlF : urlF = base + 'CallPlayer'
                elif 'uauflix' in urlF : urlF = 'https://player.uauflix.online//CallPlayer'
                data = urllib.urlencode({'id': idS})
                html = requests.post(url=urlF, data=data, headers=headers).text
                xbmc.log('[plugin.video.querofilmeshd] L311 - ' + str(html), xbmc.LOGNOTICE)
                _html = str(html)
                _html = bytes.fromhex(_html).decode('utf-8')
                b = json.loads(_html)
                xbmc.log('[plugin.video.querofilmeshd] L314 - ' + str(b), xbmc.LOGNOTICE)
                urlF = b['url']
                if '//public' in urlF : urlF = urlF.replace('//public','/public')
                fxID = urlF.split('id=')[1]
                if "&" in fxID: fxID = fxID.split('&')[0]
                if "&vlsub" in urlF:
                    sub = 'https://sub.sfplayer.net/subdata/' + urlF.split('vlsub=')[1]
                elif "&sub" in urlF:
                    sub = urlF.split('&sub=')[1]
                host = urlF.split('/public')[0]
                t = int(round(time.time() * 1000))
                urlF = host + '/playlist/' + fxID + '/' + str(t)

                r = requests.get(url=urlF)
                titsT = re.findall('RESOLUTION=(.*?)\n/hls.+', r.text)
                idsT = re.findall('RESOLUTION=.*?\n/(.*?)\n', r.text)

                if not titsT : return

                index = xbmcgui.Dialog().select('Selecione uma das fontes suportadas :', titsT)

                if index == -1 : return
                i = index
                urlVideo = host + '/' + idsT[i]
                url2Play = urlVideo
                OK = False

                xbmc.log('[plugin.video.querofilmeshd] L341 - ' + str(url2Play), xbmc.LOGNOTICE)
        except:
            pass

        xbmc.log('[plugin.video.querofilmeshd] L345 - ' + str(urlVideo), xbmc.LOGNOTICE)

        mensagemprogresso.update(50, 'Resolvendo fonte para ' + name,'Por favor aguarde...')

        if 'video.php' in urlVideo :
                html = openURL(urlVideo)
                soup = BeautifulSoup(html, 'html.parser')
                urlF = soup.iframe["src"]
                urlVideo = urlF
                xbmc.log('[plugin.video.querofilmeshd] L354 - ' + str(urlVideo), xbmc.LOGNOTICE)

        elif 'embed.mystream.to' in urlVideo:
                html = openURL(urlVideo)
                soup = BeautifulSoup(html, 'html.parser')
                urlF = soup.source["src"]
                url2Play = urlF
                xbmc.log('[plugin.video.querofilmeshd] L361 - ' + str(urlVideo), xbmc.LOGNOTICE)
                OK = False

        elif 'playercdn.net' in urlVideo:
                html = openURL(urlVideo)
                soup = BeautifulSoup(html, 'html.parser')
                urlF = soup.source["src"]
                url2Play = urlF
                xbmc.log('[plugin.video.querofilmeshd] L369 - ' + str(urlVideo), xbmc.LOGNOTICE)
                OK = False

        elif 'index.html' in urlVideo:
                url2Play = urlVideo
                xbmc.log('[plugin.video.querofilmeshd] L374 - ' + str(urlVideo), xbmc.LOGNOTICE)
                OK = False

        elif 'player.querofilmeshd.co' in urlVideo:
                r = requests.get(urlVideo)
                html = r.content
                soup = BeautifulSoup(html, 'html.parser')
                match = re.findall(r'idS:\s*"(.*?)"', html)
                xbmc.log('[plugin.video.querofilmeshd] L382 - ' + str(match), xbmc.LOGNOTICE)
                for x in match:
                    idsT.append(x)
                match = re.findall(r'\(SvID ==\s*(.*?)\) \{', html)
                for x in match:
                    x = 'Player ' + x
                    titsT.append(x)

                if not titsT : return

                index = xbmcgui.Dialog().select('Selecione uma das fontes suportadas :', titsT)

                if index == -1 : return

                i = int(index)
                idS = idsT[i]

                headers = {'Referer': url,
                           'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                           'origin': 'https://player.querofilmeshd.co',
                           'x-requested-with': 'XMLHttpRequest',
                           'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0'
                }
                xbmc.log('[plugin.video.querofilmeshd] L405 - ' + str(idS), xbmc.LOGNOTICE)
                urlF = 'https://player.querofilmeshd.co//CallPlayer'
                data = urllib.urlencode({'id': idS})
                r = requests.post(url=urlF, data=data, headers=headers)
                html = r.content
                _html = str(html)
                xbmc.log('[plugin.video.querofilmeshd] L411 - ' + str(_html), xbmc.LOGNOTICE)
                _html = bytes.fromhex(_html).decode('utf-8')
                b = json.loads(_html)
                try:
                        urlF = b['url']
                        url2Play = urlF
                        OK = False
                except:
                        pass
                try:
                        c = b['video']
                        urlF = c['file']
                        url2Play = urlF
                        OK = False
                except:
                        pass

                xbmc.log('[plugin.video.querofilmeshd] L427 - ' + str(urlVideo), xbmc.LOGNOTICE)

                if 'letsupload.co' in urlVideo:
                        nowID = urlVideo.split("=")[1]
                        urlVideo = "https://letsupload.co/plugins/mediaplayer/site/_embed.php?u=%s" % nowID
                        r = requests.get(urlVideo)
                        url2Play = re.findall(r'file: "(.+?)",', r.text)[0]
                        OK = False

                elif 'embed.mystream.to' in urlVideo:
                        html = openURL(urlVideo)
                        e = re.findall('<meta name="twitter:image" content="(.+?)">', html)[0]
                        url2Play = e.replace('/img', '').replace('jpg','mp4')
                        xbmc.log('[plugin.video.querofilmeshd] L440 - ' + str(url2Play), xbmc.LOGNOTICE)
                        OK = False

                elif 'gofilmes.me' in urlVideo:
                        headers = {
                                'Referer': urlVideo,
                                'authority': 'gofilmes.me',
                                'Upgrade-Insecure-Requests': '1',
                                'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0'
                        }
                        r = requests.get(url=urlVideo, headers=headers)
                        e = re.findall('sources:\s*\[\{[\'"]file[\'"]:[\'"](.+?)[\'"], type:[\'"]mp4[\'"], default:[\'"]true[\'"]\}\],', r.content)[0]
                        url2Play = e #+ '%7C' + urllib.urlencode(headers)
                        OK = False

                elif '4toshare' in urlVideo :
                        r = requests.get(urlVideo)
                        e = re.findall('{src:\s*"(.+?)", type: "(.+?)", res:\s*.+?, label: "(.+?)"}', r.text)
                        headers = {
                                'Referer': urlVideo,
                                'Host': 's2.4toshare.com',
                                'Upgrade-Insecure-Requests': '1',
                                'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0'
            }
                        url2Play = e[0][0] + '%7C' + urllib.urlencode(headers)
                        OK = False

                elif 'video.php' in urlVideo :
                        fxID = urlVideo.split('u=')[1]
                        urlVideo = base64.b64decode(fxID)
                        xbmc.log('[plugin.video.querofilmeshd] L470 - ' + str(urlVideo), xbmc.LOGNOTICE)
                        OK = True

                elif 'actelecup.com' in urlVideo :
                        xbmc.log('[plugin.video.querofilmeshd] L474 - ' + str(urlVideo), xbmc.LOGNOTICE)
                        urlVideo = moonwalk.get_playlist(urlVideo)
                        urlVideo = urlVideo[0]
                        qual = []
                        for i in urlVideo:
                                qual.append(str(i))
                        index = xbmcgui.Dialog().select('Selecione uma das qualidades suportadas :', qual)
                        if index == -1 : return
                        i = int(qual[index])
                        url2Play = urlVideo[i]
                        OK = False

                elif 'index.html' in url2Play :
                        host = url2Play.split('/public')[0]
                        fxID = url2Play.split('id=')[1]
                        t = int(round(time() * 1000))
                        headers = {'Referer': url2Play,
                                   'Accept-Encoding': 'gzip, deflate, br',
                                   'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:74.0) Gecko/20100101 Firefox/74.0',
                                }
                        dados = urllib.urlencode(headers)
                        urlF = host + '/playlist/' + fxID + '/' + str(t) + '.m3u8'
                        r = requests.get(urlF)
                        xbmc.log('[plugin.video.querofilmeshd] L497 - ' + str(r.text), xbmc.LOGNOTICE)
                        idsT = re.findall('RESOLUTION=.*?\n(.*?)\n',r.text)
                        if len(idsT) > 0:
                            url2Play = host + idsT[1] #+ '|' + dados
                        else:
                            url2Play = host + idsT[0] #+ '|' + dados
                        #url2Play = urlF
                        OK = False

        if OK :
            try:
                url2Play = urlresolver.resolve(urlVideo)
            except:
                dialog = xbmcgui.Dialog()
                dialog.ok(" Erro:", " Video removido! ")
                url2Play = []
                pass

        xbmc.log('[plugin.video.querofilmeshd] L515 - ' + str(url2Play), xbmc.LOGNOTICE)

        if not url2Play : return

        if sub is None:
            legendas = '-'
        else:
            legendas = sub

        mensagemprogresso.update(75, 'Abrindo Sinal para ' + name,'Por favor aguarde...')

        playlist = xbmc.PlayList(1)
        playlist.clear()

        if "m3u8" in url2Play:
                #ip = addon.getSetting("inputstream")
                listitem = xbmcgui.ListItem(name, path=url2Play)
                listitem.setArt({"thumb": iconimage, "icon": iconimage})
                listitem.setProperty('IsPlayable', 'true')
                listitem.setMimeType('application/x-mpegURL')
                listitem.setProperty('inputstreamaddon','inputstream.hls')
                listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
                #listitem.setMimeType('application/dash+xml')
                listitem.setContentLookup(False)
                playlist.add(url2Play,listitem)
        else:
                listitem = xbmcgui.ListItem(name, path=url2Play)
                listitem.setArt({"thumb": iconimage, "icon": iconimage})
                listitem.setProperty('IsPlayable', 'true')
                listitem.setMimeType('video/mp4')
                playlist.add(url2Play,listitem)

        xbmcPlayer = xbmc.Player()

        while xbmcPlayer.play(playlist) :
            xbmc.sleep(20000)
            if not xbmcPlayer.isPlaying():
                xbmc.stop()

        mensagemprogresso.update(100)
        mensagemprogresso.close()

        if legendas != '-':
            if 'timedtext' in legendas:
                    import os.path
                    sfile = os.path.join(xbmc.translatePath("special://temp"),'sub.srt')
                    sfile_xml = os.path.join(xbmc.translatePath("special://temp"),'sub.xml')#timedtext
                    sub_file_xml = open(sfile_xml,'w')
                    sub_file_xml.write(urllib2.urlopen(legendas).read())
                    sub_file_xml.close()
                    xmltosrt.main(sfile_xml)
                    xbmcPlayer.setSubtitles(sfile)
            else:
                xbmcPlayer.setSubtitles(legendas)


def player_series(name,url,iconimage):
        xbmc.log('[plugin.video.querofilmeshd] L572 - ' + str(url), xbmc.LOGNOTICE)
        OK = True
        mensagemprogresso = xbmcgui.DialogProgress()
        mensagemprogresso.create('QueroFilmesHD', 'Obtendo Fontes para ' + name, 'Por favor aguarde...')
        mensagemprogresso.update(0)

        titsT = []
        idsT = []
        links = []
        hosts = []
        sub = None

        link = openURL(url)
        link = unicode(link, 'utf-8', 'ignore')
        soup = BeautifulSoup(link, 'html.parser')
        dados = soup('li',{'id':'player-option-1'})
        xbmc.log('[plugin.video.querofilmeshd] L588 - ' + str(dados), xbmc.LOGNOTICE)
        if not dados :
                dialog = xbmcgui.Dialog()
                dialog.ok(name, " ainda não liberado, aguarde... ")
                return

        dooplay = []
        dtype = dados[0]['data-type']
        dpost = dados[0]['data-post']
        dnume = dados[0]['data-nume']

        dooplay = re.findall(r'<li id=[\'"]player-option-1[\'"] class=[\'"]dooplay_player_option[\'"] data-type=[\'"](.+?)[\'"] data-post=[\'"](.+?)[\'"] data-nume=[\'"](.+?)[\'"]>', link)

        for dtype, dpost, dnume in dooplay:
            print dtype, dpost, dnume

        try:
                headers = {'Referer': url,
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                        'Host': 'www.querofilmeshd.co',
                        'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0'
                }
                html = requests.get(url).text
                urlF = re.findall(r"<iframe class='metaframe rptss' src='(.*?)' frameborder='0' scrolling='no' allow='autoplay; encrypted-media' allowfullscreen></iframe>", html)[0]
                html = requests.get(urlF).text
                xbmc.log('[plugin.video.querofilmeshd] L613 - ' + str(urlF), xbmc.LOGNOTICE)
                idS = re.findall(r'idS=\s*"(.*?)"', html)[0]
                headers = {'Referer': urlF,
                           'Accept': '*/*',
                           'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                           'x-requested-with': 'XMLHttpRequest',
                           'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0'
                }
                urlF = 'https://player.uauflix.online//CallEpi'
                data = urllib.urlencode({'idS': idS})
                html = requests.post(url=urlF, data=data, headers=headers).content
                xbmc.log('[plugin.video.querofilmeshd] L624 - ' + str(data), xbmc.LOGNOTICE)
                _html = str(html)
                _html = bytes.fromhex(_html).decode('utf-8')
                b = json.loads(_html)
                urlF = b['url']
                if '//public' in urlF : urlF = urlF.replace('//public','/public')
                fxID = urlF.split('id=')[1]
                if "&" in fxID: fxID = fxID.split('&')[0]
                if "&vlsub" in urlF:
                    sub = 'https://sub.sfplayer.net/subdata/' + urlF.split('vlsub=')[1]
                elif "&sub" in urlF:
                    sub = urlF.split('&sub=')[1]
                host = urlF.split('/public')[0]
                t = int(round(time.time() * 1000))
                urlF = host + '/playlist/' + fxID + '/' + str(t)

                r = requests.get(url=urlF)
                titsT = re.findall('RESOLUTION=(.*?)\n/hls.+', r.text)
                idsT = re.findall('RESOLUTION=.*?\n/(.*?)\n', r.text)

                if not titsT : return

                index = xbmcgui.Dialog().select('Selecione uma das fontes suportadas :', titsT)

                if index == -1 : return
                i = index
                urlVideo = host + '/' + idsT[i]
                url2Play = urlVideo
                OK = False


                xbmc.log('[plugin.video.querofilmeshd] L654 - ' + str(urlVideo), xbmc.LOGNOTICE)
        except:
            pass
        try:
            b = json.loads(html)
            urlF = b['embed_url']
            html = requests.get(urlF).content
            xbmc.log('[plugin.video.querofilmeshd] L661 - ' + str(urlF), xbmc.LOGNOTICE)
            match = re.findall(r'idS="(.*?)"', html)
            idS = match[0]
            xbmc.log('[plugin.video.querofilmeshd] L664 - ' + str(idS), xbmc.LOGNOTICE)
            headers = {'Referer': urlF,
                       'Accept': '*/*',
                       'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                       'Host': 'player.querofilmeshd.co',
                       'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0',
                        'x-requested-with': 'XMLHttpRequest'
            }
            urlB = 'https://player.querofilmeshd.co//CallEpi'
            data = urllib.urlencode({'id': idS})
            r = requests.post(url=urlB, data=data, headers=headers)
            xbmc.log('[plugin.video.querofilmeshd] L675 - ' + str(r.text), xbmc.LOGNOTICE)
            _html = str(html)
            _html = bytes.fromhex(_html).decode('utf-8')
            b = json.loads(_html)
            urlF = b['url']
            xbmc.log('[plugin.video.querofilmeshd] L679 - ' + str(urlF), xbmc.LOGNOTICE)
            urlVideo = urlF
        except:
            pass

        if 'querofilmeshd.co' in urlVideo:
                r = requests.get(urlVideo)
                html = r.content
                #xbmc.log('[plugin.video.querofilmeshd] L687 - ' + str(html), xbmc.LOGNOTICE)
                soup = BeautifulSoup(html, 'html.parser')
                try:
                    match = re.findall(r'\("SvplayerID",{\n\t\t\t\t\t\t\tidS: "(.*?)"\n\t\t\t\t\t\t}\)', html)
                    for x in match:
                        idsT.append(x)
                except:
                    pass
                try:
                    match = re.findall('<button class="btn btn-lg" idS="(.*?)" id="btn-(.*?)" auth="0"><i id=".*?" class="glyphicon glyphicon-play-circle"></i> Iframe</button>', html)
                    for x,y in match:
                        y = 'Player ' + y
                        titsT.append(y)
                        idsT.append(x)
                except:
                    pass

                if not titsT : return

                index = xbmcgui.Dialog().select('Selecione uma das fontes suportadas :', titsT)

                if index == -1 : return

                i = int(index)
                idS = idsT[i]

                headers = {'Referer': url,
                           'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                           'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                           'Host': 'player.querofilmeshd.co',
                           'Connection': 'keep-alive',
                           'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0'
                }
                urlF ='https://player.querofilmeshd.co/CallEpi'
                data = urllib.urlencode({'idS': idS})
                r = requests.post(url=urlF, data=data, headers=headers)
                xbmc.log('[plugin.video.querofilmeshd] L723 - ' + str(data), xbmc.LOGNOTICE)
                html = r.content
                _html = str(html)
                _html = bytes.fromhex(_html).decode('utf-8')
                b = json.loads(_html
                try:
                        urlF = b['url']
                        url2Play = urlF
                        OK = False
                except:
                        pass
                try:
                        c = b['video']
                        urlF = c['file']
                        url2Play = urlF
                        OK = False
                except:
                        pass

                xbmc.log('[plugin.video.querofilmeshd] L741 - ' + str(urlF), xbmc.LOGNOTICE)

                idF = urlF.split('id=')[-1]
                urlF = 'https://player.filmesonlinetv.org/hls/%s/%s.m3u8' % (idF,idF)
                xbmc.log('[plugin.video.querofilmeshd] L745 - ' + str(urlF), xbmc.LOGNOTICE)
                r = requests.get(urlF)
                html = r.text
                html = html.replace('redirect/','')
                xbmc.log('[plugin.video.querofilmeshd] L749 - ' + str(html), xbmc.LOGNOTICE)

                urlVideo = urlF
                url2Play = urlVideo
                OK = False

                xbmc.log('[plugin.video.querofilmeshd] L755 - ' + str(urlVideo), xbmc.LOGNOTICE)

                if 'letsupload.co' in urlVideo:
                        nowID = urlVideo.split("=")[1]
                        urlVideo = "https://letsupload.co/plugins/mediaplayer/site/_embed.php?u=%s" % nowID
                        r = requests.get(urlVideo)
                        url2Play = re.findall(r'file: "(.+?)",', r.text)[0]
                        OK = False

                if 'videok7.online' in urlVideo :
                        url2Play = urlVideo
                        OK = False

                if 'saborcaseiro' in urlVideo :
                        url2Play = urlVideo
                        OK = False

                if 'apiblogger.xyz' in urlVideo :
                        headers = {'Referer': urlF2,
                                   'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0'
                        }
                        url2Play = urlVideo + "|" + urllib.urlencode(headers)
                        OK = False

                elif 'video.php' in urlVideo :
                        fxID = urlVideo.split('=')[1]
                        urlVideo = base64.b64decode(fxID)
                        xbmc.log('[plugin.video.querofilmeshd] L782 - ' + str(urlVideo), xbmc.LOGNOTICE)
                        OK = True

                        if 'alfastream.cc' in urlVideo:
                                if 'actelecup.com' in urlVideo:
                                        xbmc.log('[plugin.video.querofilmeshd] L787 - ' + str(urlVideo), xbmc.LOGNOTICE)
                                        urlVideo = moonwalk.get_playlist(urlVideo)
                                        urlVideo = urlVideo[0]
                                        qual = []
                                        for i in urlVideo:
                                                qual.append(str(i))
                                        index = xbmcgui.Dialog().select('Selecione uma das qualidades suportadas :', qual)
                                        if index == -1 : return
                                        i = int(qual[index])
                                        url2Play = urlVideo[i]
                                        OK = False

        xbmc.log('[plugin.video.querofilmeshd] L799 ' + str(urlVideo), xbmc.LOGNOTICE)

        mensagemprogresso.update(50, 'Resolvendo fonte para ' + name,'Por favor aguarde...')

        if OK : url2Play = urlresolver.resolve(urlVideo)

        if not url2Play : return

        if sub is None:
            legendas = '-'
        else:
            legendas = sub

        mensagemprogresso.update(75, 'Abrindo Sinal para ' + name,'Por favor aguarde...')

        playlist = xbmc.PlayList(1)
        playlist.clear()

        if "m3u8" in url2Play:
                #ip = addon.getSetting("inputstream")
                listitem = xbmcgui.ListItem(name, path=url2Play)
                listitem.setArt({"thumb": iconimage, "icon": iconimage})
                listitem.setProperty('IsPlayable', 'true')
                listitem.setMimeType('application/x-mpegURL')
                listitem.setProperty('inputstreamaddon','inputstream.hls')
                listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
                #listitem.setMimeType('application/dash+xml')
                listitem.setContentLookup(False)
                playlist.add(url2Play,listitem)
        else:
                listitem = xbmcgui.ListItem(name, path=url2Play)
                listitem.setArt({"thumb": iconimage, "icon": iconimage})
                listitem.setProperty('IsPlayable', 'true')
                listitem.setMimeType('video/mp4')
                playlist.add(url2Play,listitem)

        xbmcPlayer = xbmc.Player()

        while xbmcPlayer.play(playlist) :
            xbmc.sleep(20000)
            if not xbmcPlayer.isPlaying():
                xbmc.stop()

        mensagemprogresso.update(100)
        mensagemprogresso.close()

        if legendas != '-':
            if 'timedtext' in legendas:
                    import os.path
                    sfile = os.path.join(xbmc.translatePath("special://temp"),'sub.srt')
                    sfile_xml = os.path.join(xbmc.translatePath("special://temp"),'sub.xml')#timedtext
                    sub_file_xml = open(sfile_xml,'w')
                    sub_file_xml.write(urllib2.urlopen(legendas).read())
                    sub_file_xml.close()
                    xmltosrt.main(sfile_xml)
                    xbmcPlayer.setSubtitles(sfile)
            else:
                xbmcPlayer.setSubtitles(legendas)

        return OK

############################################################################################################

def openConfig():
        selfAddon.openSettings()
        setViewMenu()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def openConfigEI():
        eiID  = 'script.extendedinfo'
        eiAD  = xbmcaddon.Addon(id=eiID)

        eiAD.openSettings()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def openURL(url):
        #dialog = xbmcgui.Dialog()
        #dialog.ok("openURL Erro:", str(url))

        headers= {'Referer': url,
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.36 Safari/537.36'
        }
        link = requests.get(url).text
        return link

def postURL(url):
        headers = {'Referer': base,
                   'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                   'Host': 'www.midiaflixhd.net',
                   'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0'
        }
        response = requests.post(url=url, data='', headers=headers)
        link=response.text
        return link

def addDir(name, url, mode, iconimage, total=1, pasta=True):
        u = sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)+"&iconimage="+urllib.parse.quote_plus(iconimage)

        ok = True

        liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)

        liz.setProperty('fanart_image', fanart)
        liz.setInfo(type = "Video", infoLabels = {"title": name})

        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=pasta, totalItems=total)

        return ok

def addDirF(name,url,mode,iconimage,pasta=True,total=1,plot='') :
        u  = sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)+"&iconimage="+urllib.parse.quote_plus(iconimage)
        ok = True

        liz = xbmcgui.ListItem(name, iconImage="iconimage", thumbnailImage=iconimage)

        liz.setProperty('fanart_image', fanart)
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": plot})

        cmItems = []

        cmItems.append(('[COLOR gold]Informações do Filme[/COLOR]', 'XBMC.RunPlugin(%s?url=%s&mode=98)'%(sys.argv[0], url)))
        cmItems.append(('[COLOR red]Assistir Trailer[/COLOR]', 'XBMC.RunPlugin(%s?name=%s&url=%s&iconimage=%s&mode=99)'%(sys.argv[0], urllib.parse.quote(name), url, urllib.parse.quote(iconimage))))

        liz.addContextMenuItems(cmItems, replaceItems=False)

        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta,totalItems=total)

        return ok

def getInfo(url):
        link = openURL(url)
        titO = re.findall('<meta property="og:title" content="(.*?)" />', link)[0]

        xbmc.executebuiltin('XBMC.RunScript(script.extendedinfo,info=extendedinfo, name=%s)' % titO)

def playTrailer(name, url,iconimage):
        link = openURL(url)
        #ytID = re.findall('<a id="open-trailer" class="btn iconized trailer" data-trailer="https://www.youtube.com/embed/(.*?)rel=0&amp;controls=1&amp;showinfo=0&autoplay=0"><b>Trailler</b> <i class="icon fa fa-play"></i></a>', link)[0]
        ytID = '' #SytID.replace('?','')

        xbmc.executebuiltin('XBMC.RunPlugin("plugin://script.extendedinfo/?info=youtubevideo&&id=%s")' % ytID)

def setViewMenu() :
        xbmcplugin.setContent(int(sys.argv[1]), 'episodes')

        opcao = selfAddon.getSetting('menuVisu')

        if   opcao == '0': xbmc.executebuiltin("Container.SetViewMode(50)")
        elif opcao == '1': xbmc.executebuiltin("Container.SetViewMode(51)")
        elif opcao == '2': xbmc.executebuiltin("Container.SetViewMode(500)")

def setViewFilmes() :
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')

        opcao = selfAddon.getSetting('filmesVisu')

        if   opcao == '0': xbmc.executebuiltin("Container.SetViewMode(50)")
        elif opcao == '1': xbmc.executebuiltin("Container.SetViewMode(51)")
        elif opcao == '2': xbmc.executebuiltin("Container.SetViewMode(500)")
        elif opcao == '3': xbmc.executebuiltin("Container.SetViewMode(501)")
        elif opcao == '4': xbmc.executebuiltin("Container.SetViewMode(508)")
        elif opcao == '5': xbmc.executebuiltin("Container.SetViewMode(504)")
        elif opcao == '6': xbmc.executebuiltin("Container.SetViewMode(503)")
        elif opcao == '7': xbmc.executebuiltin("Container.SetViewMode(515)")

def limpa(texto):
        texto = texto.replace('ç','c').replace('ã','a').replace('õ','o')
        texto = texto.replace('â','a').replace('ê','e').replace('ô','o')
        texto = texto.replace('á','a').replace('é','e').replace('í','i').replace('ó','o').replace('ú','u')
        texto = texto.replace(' ','-')
        texto = texto.lower()

        return texto

def sinopse(urlF):
        link = openURL(urlF)
        link = unicode(link, 'utf-8', 'ignore')
        soup = BeautifulSoup(link, 'html.parser')
        #conteudo = soup("div", {"id": "info"})
        try:
            p = soup('p', limit=5)[0]
            plot = p.text.replace('kk-star-ratings','')
        except:
            plot = 'Sem Sinopse'
            pass
        return plot

############################################################################################################

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]

        return param

params    = get_params()
url       = None
name      = None
mode      = None
iconimage = None

try    : url=urllib.unquote_plus(params["url"])
except : pass
try    : name=urllib.unquote_plus(params["name"])
except : pass
try    : mode=int(params["mode"])
except : pass
try    : iconimage=urllib.unquote_plus(params["iconimage"])
except : pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "Iconimage: "+str(iconimage)

###############################################################################################################

if   mode == None : menuPrincipal()
elif mode == 10   : getCategorias(url)
elif mode == 20   : getFilmes(url)
elif mode == 25   : getSeries(url)
elif mode == 26   : getTemporadas(name,url,iconimage)
elif mode == 27   : getEpisodios(name,url)
elif mode == 30   : doPesquisaSeries()
elif mode == 35   : doPesquisaFilmes()
elif mode == 40   : getFavoritos()
elif mode == 41   : addFavoritos(name,url,iconimage)
elif mode == 42   : remFavoritos(name,url,iconimage)
elif mode == 43   : cleanFavoritos()
elif mode == 98   : getInfo(url)
elif mode == 99   : playTrailer(name,url,iconimage)
elif mode == 100  : player(name,url,iconimage)
elif mode == 110  : player_series(name,url,iconimage)
elif mode == 999  : openConfig()
elif mode == 1000 : openConfigEI()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
